### 2.2.1 (5 april 2018)
 - add deposit address into account transaction history

### 2.2.0 (22 match 2018)
 - add rate limiting
 
### 2.1.2 (19 february 2018)
 - add default withdraw fee for currency
 - add delisted attribute for currency

### 2.1.1 (8 february 2018) 
 - fix timeout on place stopLimit order
 - change default TimeInForce for market orders for `IOK`, for limit orders default `GTC`
 - fix on history orders: filter by symbol, add `price` on a response  
 - allow set symbol in query parameter for cancel orders
 - fix bug with default filter by the timestamp on public trades
  
### 2.1.0
 - Release SocketAPIv2

### 2.0.0
 - Release APIv2
